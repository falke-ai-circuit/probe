PROBE Client — Vegas VM Deployment Package
================================================

Contents:
  probe-client-vegas.exe    10.5 MB Windows binary with embedded config
  probe-client-vegas.json   Reference config (info only, binary has it embedded)
  README.md                 This file

Configuration (embedded in binary):
  Server:       ws://139.99.148.90:7701/ws
  Token:        falke-admin-2026
  Name:         vegas-c2022
  Mode:         silent (daemon, no console)
  Permissions:  full

Installation on Vegas:
  1. Copy probe-client-vegas.exe to vegas (C:\ or any directory)
  2. Run it (double-click or from cmd)
  3. Binary will connect to probe server and appear in agents list
  4. No config file needed — config is embedded

Verify connection:
  After running, the binary will:
  - Connect to ws://139.99.148.90:7701/ws
  - Authenticate with token falke-admin-2026
  - Register as "vegas-c2022"
  - Send periodic heartbeats
  
  You can verify by checking the probe server's /api/agents endpoint.

Uninstall:
  Just delete the .exe file. No installer, no registry, no dependencies.

Updates:
  After vegas connects, I can push new versions via the probe server's
  update endpoint. No need to manually redeploy.

Build info:
  Version:  v1.10.0
  Source:   cmd/probe-client/main.go (latest)
  Go:       go1.23.12
  Built:    2026-08-12 11:33:08 UTC
  Host:     CT100 (falke-stack)
